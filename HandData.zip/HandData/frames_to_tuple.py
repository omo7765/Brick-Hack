import numpy as np
import os
def get_file_count(letter):
    letter = letter.upper()
    return len(os.listdir(letter))

def get_trimmed_data(letter, number):
    file_name = "%s/frame%04d.txt" % (letter.upper(), number)
    frame_file = open(file_name, "r")
    lines = frame_file.readlines()
    return [line.strip() for line in lines]




def clean_to_nparray(letter, number):
    array_lines = []
    trimmed_data = get_trimmed_data(letter,number)
    for line in trimmed_data:
        fields = line.split(",")
        fields = [float(field.strip()) for field in fields]
        field_count = len(fields)
        if field_count == 6:
            array_lines.append(fields[0:3])
            array_lines.append(fields[3:6])
        else:
            array_lines.append(fields)

    return np.array(array_lines)

def construct_data_classifier_tuple():
    letters = ["R", "P", "S"]
    labels = []
    data_sets = []
    for letter in letters:
        for number in range(get_file_count(letter)):
            labels.append(labels)
            data_sets.append(clean_to_nparray(letter, number))
    return (data_sets, labels)




def main():
    print construct_data_classifier_tuple()

if __name__ == "__main__":
    main()

